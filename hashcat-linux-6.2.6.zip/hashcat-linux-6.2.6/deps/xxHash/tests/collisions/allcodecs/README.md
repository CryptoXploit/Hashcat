Put in this directory all hash algorithms to test
