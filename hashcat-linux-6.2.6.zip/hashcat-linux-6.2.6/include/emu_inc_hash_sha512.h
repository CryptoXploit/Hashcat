/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _EMU_INC_HASH_SHA512_H
#define _EMU_INC_HASH_SHA512_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_sha512.h"

#endif // _EMU_INC_HASH_SHA512_H
